a = int(input("angle"))
b = int(input("angle"))
c = int(input("angle"))

if a + b + c != 180:
  print("Error")

elif  a == b == c:
  print("equilateral")

elif a == b or a == c or b == c:
  print("isosceles")

else:
  print("scalene")